# -*- coding: utf-8 -*-

"""General functions and methods for heat capacity."""
"""Save models for heat capacity, stabilities here."""