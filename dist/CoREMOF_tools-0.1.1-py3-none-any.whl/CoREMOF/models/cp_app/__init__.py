# -*- coding: utf-8 -*-

"""General functions and methods for heat capacity."""
